# TravelGuide
Softuni TeamWork Project

Site language - English

Eli - index, article page, advanced search, user login, register, user index

stanislav - admin login, admin index, user comment on map, user add pictures on map, log out page

cvet - admin article CRUD - create, edit, delete article 

ivka - admin comments CRUD - create , edit, delete comments, manage map locations

The project is in the TravelGuide.zip. Before pushing,  zip your project into TravelGuide.zip and then push
